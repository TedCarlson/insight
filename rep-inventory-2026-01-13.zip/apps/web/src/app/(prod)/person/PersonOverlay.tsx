// apps/web/src/components/prod/PersonOverlay.tsx

'use client';

import { useEffect, useState } from 'react';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';

interface Props {
  personId?: string | null;
  open: boolean;
  onClose: () => void;
  onSaved?: () => void;
}

export default function PersonOverlay({ personId, open, onClose, onSaved }: Props) {
  const supabase = createClientComponentClient();
  const [person, setPerson] = useState<any>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!personId) return setPerson({});
    async function fetchPerson() {
      setLoading(true);
      const { data, error } = await supabase
        .from('person')
        .select('*')
        .eq('person_id', personId)
        .single();

      if (!error) setPerson(data);
      setLoading(false);
    }
    fetchPerson();
  }, [personId]);

  function handleChange(field: string, value: any) {
    setPerson((prev: any) => ({ ...prev, [field]: value }));
  }

  async function handleSave() {
    if (!person.full_name || !person.role) return;
    setLoading(true);

    const { error } = personId
      ? await supabase.from('person').update(person).eq('person_id', personId)
      : await supabase.from('person').insert(person);

    setLoading(false);
    if (!error) {
      onSaved?.();
      onClose();
    }
  }

  return (
    <Drawer open={open} onClose={onClose}>
      <DrawerContent className="p-4 space-y-4">
        <DrawerHeader>
          <DrawerTitle>{personId ? 'Edit Person' : 'Add Person'}</DrawerTitle>
        </DrawerHeader>

        <div className="space-y-2">
          <Label>Full Name</Label>
          <Input
            value={person.full_name || ''}
            onChange={(e) => handleChange('full_name', e.target.value)}
            placeholder="John Doe"
          />
        </div>

        <div className="space-y-2">
          <Label>Role</Label>
          <Input
            value={person.role || ''}
            onChange={(e) => handleChange('role', e.target.value)}
            placeholder="Technician / Supervisor"
          />
        </div>

        <div className="space-y-2">
          <Label>PC Org ID</Label>
          <Input
            value={person.org_id || ''}
            onChange={(e) => handleChange('org_id', e.target.value)}
            placeholder="UUID of assigned pc_org"
          />
        </div>

        <div className="flex gap-2 pt-4">
          <Button onClick={handleSave} disabled={loading}>
            {personId ? 'Save Changes' : 'Create Person'}
          </Button>
          <Button variant="ghost" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
