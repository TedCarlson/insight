// apps/web/src/app/(prod)/person/page.tsx

'use client';

import { useEffect, useState } from 'react';
import PersonOverlay from './PersonOverlay';
import PersonList from './PersonList';
import { Button } from '@/components/ui/button';

export default function PersonPage() {
  const [people, setPeople] = useState<any[]>([]);
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(null);
  const [overlayOpen, setOverlayOpen] = useState(false);

  async function fetchPeople() {
    try {
      const res = await fetch('/api/person');
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setPeople(data);
    } catch (err) {
      console.error('Fetch people error:', err);
    }
  }

  useEffect(() => {
    fetchPeople();
  }, []);

  function openOverlay(personId?: string) {
    setSelectedPersonId(personId || null);
    setOverlayOpen(true);
  }

  function handleSaved() {
    fetchPeople();
  }

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">People</h1>
      <Button onClick={() => openOverlay()}>Add Person</Button>
      <PersonList data={people} onEdit={openOverlay} />
      {overlayOpen && (
        <PersonOverlay
          personId={selectedPersonId}
          open={overlayOpen}
          onClose={() => setOverlayOpen(false)}
          onSaved={handleSaved}
        />
      )}
    </div>
  );
}
