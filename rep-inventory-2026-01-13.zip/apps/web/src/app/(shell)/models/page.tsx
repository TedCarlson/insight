'use client';

import { useState } from 'react';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';

const TABLES = [
    'person',
    'assignment',
    'schedule',
    'shift_validation',
    'company',
    'contractor',
    'division',
    'office',
    'route',
    'region',
];

export default function ModelsPage() {
    const [selectedTable, setSelectedTable] = useState<string | null>(null);
    const [data, setData] = useState<any[]>([]);
    const [editingRow, setEditingRow] = useState<any | null>(null);
    const [newRow, setNewRow] = useState<any>({});
    const supabase = createClientComponentClient();

    async function loadTable(table: string) {
        const { data, error } = await supabase.from(table).select('*').limit(100);
        if (error) {
            console.error('Error loading table:', error.message);
            setData([]);
        } else {
            setSelectedTable(table);
            setData(data);
            setEditingRow(null);
            setNewRow({});
        }
    }

    async function updateRow(row: any) {
        const { error } = await supabase.from(selectedTable!).update(row).eq('id', row.id);
        if (error) console.error('Update failed:', error.message);
        else await loadTable(selectedTable!);
    }

    async function deleteRow(id: any) {
        const { error } = await supabase.from(selectedTable!).delete().eq('id', id);
        if (error) console.error('Delete failed:', error.message);
        else await loadTable(selectedTable!);
    }

    async function insertRow() {
        const { error } = await supabase.from(selectedTable!).insert([newRow]);
        if (error) console.error('Insert failed:', error.message);
        else await loadTable(selectedTable!);
    }

    return (
        <main className="p-6 space-y-6">
            <h1 className="text-xl font-semibold text-[var(--to-ink)]">Models</h1>

            <div className="flex gap-4 flex-wrap">
                {TABLES.map((table) => (
                    <button
                        key={table}
                        onClick={() => loadTable(table)}
                        className="px-3 py-1 text-sm border rounded-lg bg-[var(--to-blue-050)] hover:bg-[var(--to-blue-100)] text-[var(--to-ink)]"
                    >
                        {table}
                    </button>
                ))}
            </div>

            {selectedTable && (
                <section className="mt-4 space-y-4">
                    <h2 className="font-medium text-lg text-[var(--to-ink-muted)]">
                        {selectedTable} preview
                    </h2>

                    <div className="overflow-auto border rounded-lg">
                        <table className="min-w-full text-sm">
                            <thead className="bg-[var(--to-blue-050)]">
                                <tr>
                                    {data.length > 0 &&
                                        Object.keys(data[0]).map((col) => (
                                            <th key={col} className="px-3 py-2 text-left border-b font-semibold">
                                                {col}
                                            </th>
                                        ))}
                                    <th className="px-3 py-2 border-b" />
                                </tr>
                            </thead>
                            <tbody>
                                {data.map((row, i) => {
                                    const isEditing = editingRow?.id === row.id;

                                    return (
                                        <tr key={i} className="odd:bg-white even:bg-[var(--to-blue-050)]">
                                            {Object.entries(row).map(([key, val]) => (
                                                <td key={key} className="px-3 py-2 border-b">
                                                    {isEditing ? (
                                                        <input
                                                            className="w-full border rounded px-1 text-xs"
                                                            value={editingRow?.[key] ?? ''}
                                                            onChange={(e) =>
                                                                setEditingRow({ ...editingRow, [key]: e.target.value })
                                                            }
                                                        />
                                                    ) : (
                                                        String(val)
                                                    )}
                                                </td>
                                            ))}

                                            <td className="px-3 py-2 border-b whitespace-nowrap">
                                                {isEditing ? (
                                                    <>
                                                        <button
                                                            onClick={() => updateRow(editingRow)}
                                                            className="text-blue-600 hover:underline text-xs mr-2"
                                                        >
                                                            Save
                                                        </button>
                                                        <button
                                                            onClick={() => setEditingRow(null)}
                                                            className="text-gray-500 hover:underline text-xs mr-2"
                                                        >
                                                            Cancel
                                                        </button>
                                                    </>
                                                ) : (
                                                    <button
                                                        onClick={() => setEditingRow(row)}
                                                        className="text-blue-600 hover:underline text-xs mr-2"
                                                    >
                                                        Edit
                                                    </button>
                                                )}

                                                <button
                                                    onClick={() => deleteRow(row.id)}
                                                    className="text-red-600 hover:underline text-xs"
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>

                    {data.length > 0 && (
                        <div className="mt-4">
                            <h3 className="text-sm font-semibold mb-2">Insert new row</h3>
                            <div className="flex flex-wrap gap-4">
                                {Object.keys(data[0]).map((col) => (
                                    <input
                                        key={col}
                                        placeholder={col}
                                        className="border px-2 py-1 text-sm rounded w-48"
                                        value={newRow[col] ?? ''}
                                        onChange={(e) => setNewRow({ ...newRow, [col]: e.target.value })}
                                    />
                                ))}
                            </div>
                            <button
                                onClick={insertRow}
                                className="mt-2 inline-block px-4 py-1 text-sm bg-[var(--to-blue-600)] text-white rounded hover:bg-[var(--to-blue-700)]"
                            >
                                Insert
                            </button>
                        </div>
                    )}
                </section>
            )}
        </main>
    );
}
