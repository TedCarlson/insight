export default function TasksPage() {
    return (
        <main className="p-6">
            <h1 className="text-2xl font-bold mb-4">Tasks</h1>
            <p className="text-gray-600">Assignment flows, shift validations, and ops checks.</p>
        </main>
    );
}
