// apps/web/src/app/api/route-lock/quota/upsert/route.ts
import { NextResponse } from "next/server";

// ⬇️ adjust this import to your actual server supabase helper
import { supabaseServer } from "@/lib/supabase/server";

export const runtime = "nodejs";

type QuotaUpsertRow = {
  quota_id?: string;
  route_id: string;
  fiscal_month_id: string;
  qh_sun: number;
  qh_mon: number;
  qh_tue: number;
  qh_wed: number;
  qh_thu: number;
  qh_fri: number;
  qh_sat: number;
};

export async function POST(req: Request) {
  const supabase = await supabaseServer(); // ✅ must await

  const {
    data: { user },
    error: userErr,
  } = await supabase.auth.getUser();

  if (userErr || !user) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const rows = (body?.rows ?? []) as QuotaUpsertRow[];

  if (!Array.isArray(rows) || rows.length === 0) {
    return NextResponse.json({ ok: false, error: "No rows provided" }, { status: 400 });
  }

  // sanitize numeric fields
  const clean = rows.map((r) => ({
    quota_id: r.quota_id,
    route_id: String(r.route_id).trim(),
    fiscal_month_id: String(r.fiscal_month_id).trim(),
    qh_sun: Number(r.qh_sun ?? 0) || 0,
    qh_mon: Number(r.qh_mon ?? 0) || 0,
    qh_tue: Number(r.qh_tue ?? 0) || 0,
    qh_wed: Number(r.qh_wed ?? 0) || 0,
    qh_thu: Number(r.qh_thu ?? 0) || 0,
    qh_fri: Number(r.qh_fri ?? 0) || 0,
    qh_sat: Number(r.qh_sat ?? 0) || 0,
  }));

  // If you have a unique constraint on (route_id, fiscal_month_id), this is correct:
  const { data, error } = await supabase
    .from("quota")
    .upsert(clean, { onConflict: "route_id,fiscal_month_id" })
    .select("quota_id, route_id, fiscal_month_id");

  if (error) {
    return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true, saved: data ?? [] });
}