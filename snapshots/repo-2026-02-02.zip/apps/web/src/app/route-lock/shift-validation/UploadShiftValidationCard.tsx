"use client";

import { useMemo, useState } from "react";
import { Card } from "@/components/ui/Card";

type Result =
  | { ok: true; row_count_loaded: number; row_count_total: number; today: string; fulfillment_center_id: number; batch_id?: string | null }
  | { ok: false; error: string; hint?: string; expected?: any; received?: any; detail?: any };

export function UploadShiftValidationCard() {
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const canUpload = useMemo(() => Boolean(file && !busy), [file, busy]);

  async function onUpload() {
    if (!file) return;
    setBusy(true);
    setResult(null);

    try {
      const fd = new FormData();
      fd.append("file", file);

      const res = await fetch("/api/route-lock/shift-validation/upload", {
        method: "POST",
        body: fd,
      });

      const json = (await res.json().catch(() => null)) as Result | null;
      setResult(json ?? { ok: false, error: "invalid response" });

      if (res.ok) {
        // Refresh server components data
        window.location.reload();
      }
    } catch (e: any) {
      setResult({ ok: false, error: String(e?.message ?? e) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card>
      <div className="space-y-3">
        <div>
          <div className="text-sm font-medium">Upload customer Shift Validation (XLSX)</div>
          <div className="text-sm text-[var(--to-ink-muted)]">
            The file is parsed in-memory; no source material is stored. Rows from today onward replace the current forward window.
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <input
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            disabled={busy}
          />
          <button className="to-btn to-btn--primary px-4 py-2" disabled={!canUpload} onClick={onUpload}>
            {busy ? "Uploading…" : "Upload"}
          </button>
        </div>

        {result && (
          <div className="text-sm">
            {result.ok ? (
              <div className="space-y-1">
                <div>
                  ✅ Loaded <span className="font-medium">{result.row_count_loaded}</span> / {result.row_count_total} rows
                </div>
                <div className="text-[var(--to-ink-muted)]">
                  Fulfillment Center ID: {result.fulfillment_center_id} · Forward window starts: {result.today}
                </div>
              </div>
            ) : (
              <div className="space-y-1">
                <div className="text-red-600">❌ {result.error}</div>
                {result.hint && <div className="text-[var(--to-ink-muted)]">{result.hint}</div>}
                {result.expected !== undefined && result.received !== undefined && (
                  <div className="text-[var(--to-ink-muted)]">
                    Expected: {String(result.expected)} · Received: {String(result.received)}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}
