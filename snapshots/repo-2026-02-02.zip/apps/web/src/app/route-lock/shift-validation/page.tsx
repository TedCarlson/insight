// apps/web/src/app/route-lock/shift-validation/page.tsx
import { cookies } from "next/headers";
import Link from "next/link";
import { createServerClient } from "@supabase/ssr";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UploadShiftValidationCard } from "./UploadShiftValidationCard";

export const runtime = "nodejs";

function todayInNY(): string {
  // YYYY-MM-DD in America/New_York
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function addDaysISO(iso: string, days: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function dowShort(iso: string): string {
  const d = new Date(`${iso}T00:00:00Z`);
  return new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: "America/New_York" }).format(d);
}

type ImportRow = {
  shift_date: string;
  tech_id: string;
  shift_duration: number | null;
  target_unit: number | null;
  route_criteria: string | null;
  route_areas: string | null;
  office: string | null;
};

export default async function ShiftValidationPage() {
  const cookieStore = await cookies();

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

  const supabase = createServerClient(url, anon, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll() {
        // no-op on server component render
      },
    },
  });

  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Org selection (server-rendered info)
  let pc_org_id: string | null = null;
  if (user) {
    const { data: prof } = await supabase
      .from("user_profile")
      .select("selected_pc_org_id")
      .eq("auth_user_id", user.id)
      .maybeSingle();
    pc_org_id = (prof?.selected_pc_org_id as string | null) ?? null;
  }

  const today = todayInNY();
  const windowEnd = addDaysISO(today, 14); // exclusive upper bound

  // Latest batch summary
  const { data: latestBatch } = pc_org_id
    ? await supabase
        .from("shift_validation_batch")
        .select("fulfillment_center_id, row_count_loaded, row_count_total, uploaded_at")
        .eq("pc_org_id", pc_org_id)
        .order("uploaded_at", { ascending: false })
        .limit(1)
        .maybeSingle()
    : ({ data: null } as any);

  // Row-level view for current window
  const { data: rows } = pc_org_id
    ? await supabase
        .from("shift_validation_import_v")
        .select("shift_date, tech_id, shift_duration, target_unit, route_criteria, route_areas, office")
        .eq("pc_org_id", pc_org_id)
        .gte("shift_date", today)
        .lt("shift_date", windowEnd)
        .order("shift_date", { ascending: true })
        .order("tech_id", { ascending: true })
    : ({ data: [] } as any);

  const typedRows: ImportRow[] = (rows ?? []) as any;

  // Daily rollup (compute on server from the fetched rows)
  const rollupMap = new Map<
    string,
    { shift_date: string; techs: Set<string>; totalUnits: number; totalHours: number }
  >();

  for (const r of typedRows) {
    const key = r.shift_date;
    if (!rollupMap.has(key)) {
      rollupMap.set(key, { shift_date: key, techs: new Set<string>(), totalUnits: 0, totalHours: 0 });
    }
    const agg = rollupMap.get(key)!;
    if (r.tech_id) agg.techs.add(String(r.tech_id));
    if (typeof r.target_unit === "number") agg.totalUnits += r.target_unit;
    if (typeof r.shift_duration === "number") agg.totalHours += r.shift_duration;
  }

  const rollups = Array.from(rollupMap.values()).sort((a, b) => a.shift_date.localeCompare(b.shift_date));

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Shift Validation</h1>
          <p className="text-sm text-muted-foreground">Route Lock • Customer snapshot ingestion + review</p>
        </div>
        <Link
          href="/route-lock"
          className="inline-flex items-center rounded-md border px-3 py-2 text-sm hover:bg-muted"
        >
          Back
        </Link>
      </div>

      <UploadShiftValidationCard />

      <Card>
        <CardHeader>
          <CardTitle>Context</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <div>
            <span className="font-medium text-foreground">Selected org:</span>{" "}
            {pc_org_id ? pc_org_id : "—"}
          </div>
          <div>
            <span className="font-medium text-foreground">Latest batch:</span>{" "}
            {latestBatch
              ? `FC ${latestBatch.fulfillment_center_id} · ${latestBatch.row_count_loaded}/${latestBatch.row_count_total} rows · ${new Date(
                  latestBatch.uploaded_at
                ).toLocaleString()}`
              : "No uploads yet"}
          </div>
          <div>
            <span className="font-medium text-foreground">Window:</span> {today} → {addDaysISO(today, 14)} (14 days,
            starting today)
          </div>
        </CardContent>
      </Card>

      {/* Two-column split */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Left: row table */}
        <Card>
          <CardHeader>
            <CardTitle>Imported rows</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-4">Shift Date</th>
                  <th className="py-2 pr-4">Tech #</th>
                  <th className="py-2 pr-4">Shift Duration</th>
                  <th className="py-2 pr-4">Target Unit</th>
                  <th className="py-2 pr-4">Route Criteria</th>
                  <th className="py-2 pr-4">Route Areas</th>
                  <th className="py-2 pr-4">Office</th>
                </tr>
              </thead>
              <tbody>
                {typedRows.length === 0 ? (
                  <tr>
                    <td className="py-6 text-muted-foreground" colSpan={7}>
                      No rows in the current 14-day window.
                    </td>
                  </tr>
                ) : (
                  typedRows.slice(0, 200).map((r, idx) => (
                    <tr key={`${r.shift_date}-${r.tech_id}-${idx}`} className="border-b last:border-b-0">
                      <td className="py-2 pr-4">{r.shift_date}</td>
                      <td className="py-2 pr-4">{r.tech_id}</td>
                      <td className="py-2 pr-4">{r.shift_duration ?? ""}</td>
                      <td className="py-2 pr-4">{r.target_unit ?? ""}</td>
                      <td className="py-2 pr-4">{r.route_criteria ?? ""}</td>
                      <td className="py-2 pr-4">{r.route_areas ?? ""}</td>
                      <td className="py-2 pr-4">{r.office ?? ""}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            {typedRows.length > 200 ? (
              <div className="mt-3 text-xs text-muted-foreground">
                Showing first 200 rows (for performance). We can add pagination next.
              </div>
            ) : null}
          </CardContent>
        </Card>

        {/* Right: daily rollup */}
        <Card>
          <CardHeader>
            <CardTitle>Daily rollup</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-4">Date</th>
                  <th className="py-2 pr-4">DOW</th>
                  <th className="py-2 pr-4">Techs Built</th>
                  <th className="py-2 pr-4">Total Units</th>
                  <th className="py-2 pr-4">Total Hours</th>
                </tr>
              </thead>
              <tbody>
                {rollups.length === 0 ? (
                  <tr>
                    <td className="py-6 text-muted-foreground" colSpan={5}>
                      No rows to roll up in the current window.
                    </td>
                  </tr>
                ) : (
                  rollups.map((d) => (
                    <tr key={d.shift_date} className="border-b last:border-b-0">
                      <td className="py-2 pr-4">{d.shift_date}</td>
                      <td className="py-2 pr-4">{dowShort(d.shift_date)}</td>
                      <td className="py-2 pr-4">{d.techs.size}</td>
                      <td className="py-2 pr-4">{Math.round(d.totalUnits)}</td>
                      <td className="py-2 pr-4">{Number.isFinite(d.totalHours) ? d.totalHours.toFixed(1) : ""}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            <div className="mt-3 text-xs text-muted-foreground">
              Rollup is computed from the loaded rows in the 14-day window (today onward).
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}