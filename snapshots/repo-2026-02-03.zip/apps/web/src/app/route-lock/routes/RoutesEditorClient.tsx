// apps/web/src/app/route-lock/routes/RoutesEditorClient.tsx
"use client";

import RoutesAdminClient from "./RoutesAdminClient";

export default RoutesAdminClient;