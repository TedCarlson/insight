"use client";

import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/Card";

type Frame = "AM" | "PM";

type StateRow = {
  state: string;
  state_code: string;
};

type TicketInputs = {
  manpower_count: number | "";
  tickets_received_am: number | ""; // only relevant in AM
  tickets_closed_pm: number | ""; // only relevant in PM
  tickets_per_week: number | "";
  project_tickets: number | "";
  emergency_tickets: number | "";
};

type GridRow = {
  state: string;
  state_code: string;
  inputs: TicketInputs;
};

type SubmittedRow = {
  call_log_key: string; // YYYY-MM-DD|AM|TX
  log_date: string; // YYYY-MM-DD
  frame: Frame;
  state: string;
  state_code: string;

  manpower_count: number;
  tickets_total: number; // received (AM) or closed (PM)
  tickets_per_week: number;
  project_tickets: number;
  emergency_tickets: number;

  avg_tickets_per_tech: number; // calculated
  created_at_iso: string;
};

const STATES: StateRow[] = [
  { state: "Florida", state_code: "FL" },
  { state: "Texas", state_code: "TX" },
  { state: "Alabama", state_code: "AL" },
  { state: "Louisiana", state_code: "LA" },
  { state: "Mississippi", state_code: "MS" },
  { state: "Washington", state_code: "WA" },
  { state: "Arizona", state_code: "AZ" },
  { state: "Connecticut", state_code: "CT" },
  { state: "Massachusetts", state_code: "MA" },
  { state: "New Mexico", state_code: "NM" },
  { state: "New York", state_code: "NY" },
  { state: "Arkansas", state_code: "AR" },
  { state: "Tennessee", state_code: "TN" },
  { state: "Kentucky", state_code: "KY" },
  { state: "South Carolina", state_code: "SC" },
];

function todayISODateLocal(): string {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function detectFrameLocal(): Frame {
  // simple heuristic: before 12:00 = AM, else PM
  const h = new Date().getHours();
  return h < 12 ? "AM" : "PM";
}

function toNum(v: number | ""): number {
  return v === "" ? 0 : Number(v);
}

function safeAvg(totalTickets: number, manpower: number): number {
  if (!manpower || manpower <= 0) return 0;
  // keep 2 decimals for readability
  return Math.round((totalTickets / manpower) * 100) / 100;
}

function makeEmptyInputs(): TicketInputs {
  return {
    manpower_count: "",
    tickets_received_am: "",
    tickets_closed_pm: "",
    tickets_per_week: "",
    project_tickets: "",
    emergency_tickets: "",
  };
}

export default function LocateDailyCallLogClient() {
  const [logDate, setLogDate] = useState<string>(() => todayISODateLocal());
  const [frame, setFrame] = useState<Frame>(() => detectFrameLocal());
  const [filter, setFilter] = useState<string>("");

  const [rows, setRows] = useState<GridRow[]>(
    STATES.map((s) => ({ ...s, inputs: makeEmptyInputs() }))
  );

  const [submitted, setSubmitted] = useState<SubmittedRow[]>([]);
  const [out, setOut] = useState<string>("");

  useEffect(() => {
    // Keep initial frame aligned with local time on first mount; allow manual override afterward
    setFrame(detectFrameLocal());
  }, []);

  const filteredRows = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) => r.state.toLowerCase().includes(q) || r.state_code.toLowerCase().includes(q));
  }, [rows, filter]);

  function updateRow(state_code: string, patch: Partial<TicketInputs>) {
    setRows((prev) =>
      prev.map((r) => {
        if (r.state_code !== state_code) return r;
        return { ...r, inputs: { ...r.inputs, ...patch } };
      })
    );
  }

  function calcTicketsTotal(inputs: TicketInputs): number {
    return frame === "AM" ? toNum(inputs.tickets_received_am) : toNum(inputs.tickets_closed_pm);
  }

  function validateAll(): string[] {
    const errs: string[] = [];
    for (const r of rows) {
      // Only validate rows that have *any* data entered (so blank states can be skipped)
      const any =
        r.inputs.manpower_count !== "" ||
        r.inputs.tickets_received_am !== "" ||
        r.inputs.tickets_closed_pm !== "" ||
        r.inputs.tickets_per_week !== "" ||
        r.inputs.project_tickets !== "" ||
        r.inputs.emergency_tickets !== "";

      if (!any) continue;

      const manpower = toNum(r.inputs.manpower_count);
      if (manpower < 0) errs.push(`${r.state}: manpower cannot be negative`);
      if (frame === "AM" && toNum(r.inputs.tickets_received_am) < 0) errs.push(`${r.state}: tickets received cannot be negative`);
      if (frame === "PM" && toNum(r.inputs.tickets_closed_pm) < 0) errs.push(`${r.state}: tickets closed cannot be negative`);

      if (toNum(r.inputs.tickets_per_week) < 0) errs.push(`${r.state}: tickets/week cannot be negative`);
      if (toNum(r.inputs.project_tickets) < 0) errs.push(`${r.state}: project tickets cannot be negative`);
      if (toNum(r.inputs.emergency_tickets) < 0) errs.push(`${r.state}: emergency tickets cannot be negative`);
    }
    return errs;
  }

  function onSubmitBatch() {
    setOut("");

    const errs = validateAll();
    if (errs.length) {
      setOut(errs.join("\n"));
      return;
    }

    const nowIso = new Date().toISOString();
    const next: SubmittedRow[] = [];

    for (const r of rows) {
      const any =
        r.inputs.manpower_count !== "" ||
        r.inputs.tickets_received_am !== "" ||
        r.inputs.tickets_closed_pm !== "" ||
        r.inputs.tickets_per_week !== "" ||
        r.inputs.project_tickets !== "" ||
        r.inputs.emergency_tickets !== "";

      if (!any) continue;

      const manpower = toNum(r.inputs.manpower_count);
      const tickets_total = calcTicketsTotal(r.inputs);

      const call_log_key = `${logDate}|${frame}|${r.state_code}`;

      next.push({
        call_log_key,
        log_date: logDate,
        frame,
        state: r.state,
        state_code: r.state_code,

        manpower_count: manpower,
        tickets_total,
        tickets_per_week: toNum(r.inputs.tickets_per_week),
        project_tickets: toNum(r.inputs.project_tickets),
        emergency_tickets: toNum(r.inputs.emergency_tickets),

        avg_tickets_per_tech: safeAvg(tickets_total, manpower),
        created_at_iso: nowIso,
      });
    }

    if (!next.length) {
      setOut("Nothing to submit yet. Enter at least one state row.");
      return;
    }

    // For now, store in-memory. Next step will persist to DB and support recall/edit.
    setSubmitted((prev) => [...next, ...prev]);

    // Reset inputs after submit (keep date/frame)
    setRows(STATES.map((s) => ({ ...s, inputs: makeEmptyInputs() })));
    setOut(`Submitted ${next.length} row(s).`);
  }

  return (
    <div className="grid gap-4">
      {/* Top card: batch entry */}
      <Card>
        <div className="grid gap-3">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <div className="text-sm font-medium">Daily call log</div>
              <div className="text-sm text-[var(--to-ink-muted)]">
                Batch entry by State. Frame auto-detects but you can override.
              </div>
            </div>

            <div className="flex flex-wrap items-end gap-3">
              <label className="grid gap-1">
                <span className="text-xs text-[var(--to-ink-muted)]">Date</span>
                <input
                  type="date"
                  className="rounded border px-3 py-2 text-sm"
                  style={{ borderColor: "var(--to-border)", background: "transparent" }}
                  value={logDate}
                  onChange={(e) => setLogDate(e.target.value)}
                />
              </label>

              <label className="grid gap-1">
                <span className="text-xs text-[var(--to-ink-muted)]">Frame</span>
                <select
                  className="rounded border px-3 py-2 text-sm"
                  style={{ borderColor: "var(--to-border)", background: "transparent" }}
                  value={frame}
                  onChange={(e) => setFrame(e.target.value as Frame)}
                >
                  <option value="AM">AM (tickets received)</option>
                  <option value="PM">PM (tickets closed)</option>
                </select>
              </label>

              <label className="grid gap-1">
                <span className="text-xs text-[var(--to-ink-muted)]">Filter states</span>
                <input
                  className="rounded border px-3 py-2 text-sm"
                  style={{ borderColor: "var(--to-border)", background: "transparent" }}
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                  placeholder="Type state or code…"
                />
              </label>

              <button
                type="button"
                onClick={onSubmitBatch}
                className="rounded border px-3 py-2 text-sm font-medium hover:bg-[var(--to-surface-2)]"
                style={{ borderColor: "var(--to-border)" }}
              >
                Submit batch
              </button>
            </div>
          </div>

          <div className="overflow-auto rounded border" style={{ borderColor: "var(--to-border)" }}>
            <table className="min-w-[1100px] w-full text-sm">
              <thead className="bg-[var(--to-surface-2)]">
                <tr className="text-left">
                  <th className="p-2">State</th>
                  <th className="p-2">Manpower</th>
                  <th className="p-2">{frame === "AM" ? "Tickets received (AM)" : "Tickets closed (PM)"}</th>
                  <th className="p-2">Tickets / Week</th>
                  <th className="p-2">Project</th>
                  <th className="p-2">Emergency</th>
                  <th className="p-2">Avg tickets / tech</th>
                  <th className="p-2">Key</th>
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((r) => {
                  const ticketsTotal = calcTicketsTotal(r.inputs);
                  const manpower = toNum(r.inputs.manpower_count);
                  const avg = safeAvg(ticketsTotal, manpower);
                  const key = `${logDate}|${frame}|${r.state_code}`;

                  return (
                    <tr key={r.state_code} className="border-t" style={{ borderColor: "var(--to-border)" }}>
                      <td className="p-2 font-medium">
                        {r.state} <span className="text-xs text-[var(--to-ink-muted)]">({r.state_code})</span>
                      </td>

                      <td className="p-2">
                        <input
                          inputMode="numeric"
                          className="w-24 rounded border px-2 py-1"
                          style={{ borderColor: "var(--to-border)", background: "transparent" }}
                          value={r.inputs.manpower_count}
                          onChange={(e) =>
                            updateRow(r.state_code, {
                              manpower_count: e.target.value === "" ? "" : Number(e.target.value),
                            })
                          }
                        />
                      </td>

                      <td className="p-2">
                        {frame === "AM" ? (
                          <input
                            inputMode="numeric"
                            className="w-36 rounded border px-2 py-1"
                            style={{ borderColor: "var(--to-border)", background: "transparent" }}
                            value={r.inputs.tickets_received_am}
                            onChange={(e) =>
                              updateRow(r.state_code, {
                                tickets_received_am: e.target.value === "" ? "" : Number(e.target.value),
                              })
                            }
                          />
                        ) : (
                          <input
                            inputMode="numeric"
                            className="w-36 rounded border px-2 py-1"
                            style={{ borderColor: "var(--to-border)", background: "transparent" }}
                            value={r.inputs.tickets_closed_pm}
                            onChange={(e) =>
                              updateRow(r.state_code, {
                                tickets_closed_pm: e.target.value === "" ? "" : Number(e.target.value),
                              })
                            }
                          />
                        )}
                      </td>

                      <td className="p-2">
                        <input
                          inputMode="numeric"
                          className="w-32 rounded border px-2 py-1"
                          style={{ borderColor: "var(--to-border)", background: "transparent" }}
                          value={r.inputs.tickets_per_week}
                          onChange={(e) =>
                            updateRow(r.state_code, {
                              tickets_per_week: e.target.value === "" ? "" : Number(e.target.value),
                            })
                          }
                        />
                      </td>

                      <td className="p-2">
                        <input
                          inputMode="numeric"
                          className="w-28 rounded border px-2 py-1"
                          style={{ borderColor: "var(--to-border)", background: "transparent" }}
                          value={r.inputs.project_tickets}
                          onChange={(e) =>
                            updateRow(r.state_code, {
                              project_tickets: e.target.value === "" ? "" : Number(e.target.value),
                            })
                          }
                        />
                      </td>

                      <td className="p-2">
                        <input
                          inputMode="numeric"
                          className="w-28 rounded border px-2 py-1"
                          style={{ borderColor: "var(--to-border)", background: "transparent" }}
                          value={r.inputs.emergency_tickets}
                          onChange={(e) =>
                            updateRow(r.state_code, {
                              emergency_tickets: e.target.value === "" ? "" : Number(e.target.value),
                            })
                          }
                        />
                      </td>

                      <td className="p-2">
                        <span className="rounded border px-2 py-1 text-xs" style={{ borderColor: "var(--to-border)" }}>
                          {avg}
                        </span>
                      </td>

                      <td className="p-2">
                        <code className="text-xs text-[var(--to-ink-muted)]">{key}</code>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {out && (
            <pre
              className="whitespace-pre-wrap rounded border p-3 text-xs"
              style={{ borderColor: "var(--to-border)", background: "var(--to-surface-2)" }}
            >
              {out}
            </pre>
          )}
        </div>
      </Card>

      {/* Bottom card: submitted rows */}
      <Card>
        <div className="grid gap-2">
          <div className="text-sm font-medium">Submitted logs (in-memory for now)</div>
          <div className="text-sm text-[var(--to-ink-muted)]">
            Next step: persist to DB, support recall/edit, and add filters (date, frame, state).
          </div>

          <div className="overflow-auto rounded border" style={{ borderColor: "var(--to-border)" }}>
            <table className="min-w-[900px] w-full text-sm">
              <thead className="bg-[var(--to-surface-2)]">
                <tr className="text-left">
                  <th className="p-2">Key</th>
                  <th className="p-2">Date</th>
                  <th className="p-2">Frame</th>
                  <th className="p-2">State</th>
                  <th className="p-2">Manpower</th>
                  <th className="p-2">Tickets total</th>
                  <th className="p-2">Avg/tech</th>
                  <th className="p-2">Created</th>
                </tr>
              </thead>
              <tbody>
                {submitted.length === 0 ? (
                  <tr>
                    <td className="p-3 text-[var(--to-ink-muted)]" colSpan={8}>
                      No submissions yet.
                    </td>
                  </tr>
                ) : (
                  submitted.map((s) => (
                    <tr key={`${s.call_log_key}-${s.created_at_iso}`} className="border-t" style={{ borderColor: "var(--to-border)" }}>
                      <td className="p-2">
                        <code className="text-xs">{s.call_log_key}</code>
                      </td>
                      <td className="p-2">{s.log_date}</td>
                      <td className="p-2">{s.frame}</td>
                      <td className="p-2">
                        {s.state} <span className="text-xs text-[var(--to-ink-muted)]">({s.state_code})</span>
                      </td>
                      <td className="p-2">{s.manpower_count}</td>
                      <td className="p-2">{s.tickets_total}</td>
                      <td className="p-2">{s.avg_tickets_per_tech}</td>
                      <td className="p-2">
                        <span className="text-xs text-[var(--to-ink-muted)]">
                          {new Date(s.created_at_iso).toLocaleString()}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </Card>
    </div>
  );
}