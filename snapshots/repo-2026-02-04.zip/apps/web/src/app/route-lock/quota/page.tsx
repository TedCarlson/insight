// apps/web/src/app/route-lock/quota/page.tsx
import QuotaAdminClient from "./QuotaAdminClient";

export default function QuotaPage() {
  return <QuotaAdminClient />;
}